﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE_4
{
    public partial class TRIANGULOS : Form
    {
        Double LADOA, LADOB, LADOC;

        private void txtladob_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtladob.Text, out LADOB))

                MessageBox.Show("Valor Inválido");
            else
               if (LADOB <= 0)
                MessageBox.Show("Numero não pode ser menor que zero");
        }

        private void txtladoa_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtladoa.Text, out LADOA))

                MessageBox.Show("Valor Inválido");
            else
               if (LADOA <= 0)
                MessageBox.Show("Numero não pode ser menor que zero");
        }

        private void txtladoc_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtladoc.Text, out LADOC))

                MessageBox.Show("Valor Inválido");
            else
               if (LADOC <= 0)
                MessageBox.Show("Numero não pode ser menor que zero");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtladoa.Clear();
            txtladob.Clear();
            txtladoc.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                if (double.TryParse(txtladoa.Text, out LADOA) && double.TryParse(txtladob.Text, out LADOB) && double.TryParse(txtladoc.Text, out LADOC))
                {
                    if (LADOA < (LADOB + LADOC) && LADOA > Math.Abs(LADOB - LADOC) && LADOB < (LADOA + LADOC) && LADOB > Math.Abs(LADOA - LADOC) && LADOC < (LADOA + LADOB) && LADOC > Math.Abs(LADOA - LADOB))
                    {


                        if (LADOA == LADOB && LADOB == LADOC)
                            MessageBox.Show("Triangulo Equilatero");
                        else if (LADOA == LADOB || LADOA == LADOC || LADOB == LADOC)
                            MessageBox.Show("Triangulo Isosceles");
                        else if
                        (LADOA != LADOB && LADOB != LADOC && LADOA != LADOC)
                            MessageBox.Show("Triangulo Escaleno");
                                            }
                    else
                        MessageBox.Show("Os valores não formam um triângulo");
                }
            }
        }

        public TRIANGULOS()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {

        }
    }
}
